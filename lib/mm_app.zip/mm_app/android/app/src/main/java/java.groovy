enum java {

    enum lang {
        enum ing {}
    }
}